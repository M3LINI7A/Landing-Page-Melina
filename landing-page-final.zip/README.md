# Landing Page con Vite + React + TailwindCSS

Este proyecto es una landing page moderna construida con:

- ⚡ [Vite](https://vitejs.dev/) — empaquetador ultrarrápido.
- ⚛️ [React](https://reactjs.org/) — biblioteca para interfaces de usuario.
- 🎨 [TailwindCSS](https://tailwindcss.com/) — framework CSS utilitario.

## 🚀 Características

- Diseño responsive
- Componentes reutilizables
- Secciones: Header, Hero, Beneficios, Testimonios, Formulario de Contacto, Footer
- Fácil de personalizar

## 📦 Estructura del Proyecto

```
.
├── public/             # Archivos estáticos
│   └── index.html
├── src/                # Código fuente
│   ├── components/     # Componentes React
│   ├── pages/          # Vistas principales
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── package.json        # Dependencias y scripts
├── vite.config.js      # Configuración de Vite
├── tailwind.config.js  # Configuración de Tailwind
└── .gitignore
```

## 🛠️ Instalación

1. Clona el repositorio o descomprime el ZIP.
2. Instala las dependencias:

```bash
npm install
```

3. Inicia el servidor de desarrollo:

```bash
npm run dev
```

## 📄 Licencia

Este proyecto está bajo licencia MIT. Puedes usarlo, modificarlo y compartirlo libremente.

---

Hecho con ❤️ para fines educativos y demostrativos.
